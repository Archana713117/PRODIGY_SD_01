
package com.mycompany.temperatureconverter;
import java.util.Scanner;
public class TemperatureConverter {

    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for temperature value
        System.out.print("Enter the temperature value: ");
        double temperature = scanner.nextDouble();

        // Prompt the user for the unit of measurement
        System.out.print("Enter the unit of measurement (C for Celsius, F for Fahrenheit, K for Kelvin): ");
        char unit = scanner.next().toUpperCase().charAt(0);

        // Perform conversion based on the unit of measurement
        switch (unit) {
            case 'C':
                // Convert Celsius to Fahrenheit and Kelvin
                double celsiusToFahrenheit = (temperature * 9/5) + 32;
                double celsiusToKelvin = temperature + 273.15;
                System.out.printf("Temperature in Fahrenheit: %.2f F%n", celsiusToFahrenheit);
                System.out.printf("Temperature in Kelvin: %.2f K%n", celsiusToKelvin);
                break;

            case 'F':
                // Convert Fahrenheit to Celsius and Kelvin
                double fahrenheitToCelsius = (temperature - 32) * 5/9;
                double fahrenheitToKelvin = (temperature - 32) * 5/9 + 273.15;
                System.out.printf("Temperature in Celsius: %.2f C%n", fahrenheitToCelsius);
                System.out.printf("Temperature in Kelvin: %.2f K%n", fahrenheitToKelvin);
                break;

            case 'K':
                // Convert Kelvin to Celsius and Fahrenheit
                double kelvinToCelsius = temperature - 273.15;
                double kelvinToFahrenheit = (temperature - 273.15) * 9/5 + 32;
                System.out.printf("Temperature in Celsius: %.2f C%n", kelvinToCelsius);
                System.out.printf("Temperature in Fahrenheit: %.2f F%n", kelvinToFahrenheit);
                break;

            default:
                System.out.println("Invalid unit of measurement. Please enter C, F, or K.");
                break;
        }

        scanner.close();
    }
}
    